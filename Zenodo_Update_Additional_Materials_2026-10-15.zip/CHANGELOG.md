# Changelog for Zenodo record update

## 2026-10-15

Added reproducibility material for manuscript revisions introduced after the original archive:

1. Exact treated-system Taylor-jet identifiability calculation for fixed Hill exponent `n=2`.
2. Exact rank certificates for 8/8, 9/9 and 11/11 treated observation scenarios.
3. Matched initial-killing comparison between surface-scaled and volume-proportional treatment mechanisms.
4. `Emax=1` versus `Emax=1.5` mechanism comparison.
5. Symmetry-related untreated trajectories and synthetic log-noise likelihood-slice demonstration.
6. Near-boundary closed-form periodic-average checks.
7. Regenerated manuscript Figures 5, 6 and 7 and machine-readable supporting CSV files.
8. Snapshot of the latest manuscript source for traceability.

This update does not replace the previously archived core simulation material; it supplements it.
