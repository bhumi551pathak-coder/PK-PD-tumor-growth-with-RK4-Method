# Zenodo update package — October 2026

This is a **delta/update package** for the existing Zenodo record cited in the manuscript:

**https://doi.org/10.5281/zenodo.23313540**

It contains the additional reproducibility material introduced in the latest manuscript revision, rather than duplicating the earlier core simulation archive.

## What is new in this package

### 1. Treated structural-identifiability certificate
`scripts/treated_identifiability_exact.py`

Exact rational Taylor-jet calculations for the first inter-dose interval with fixed Hill exponent `n = 2`.

The script verifies:

- known nonconstant `C(t)`, tumour output observed: **rank 8/8** for the six reduced tumour–immune quantities plus `Emax` and `K = EC50^2`;
- tumour and concentration observed, with `k` unknown: **rank 9/9**;
- tumour, immune and concentration jointly observed: **rank 11/11** for the remaining continuous unknowns.

The exact ranks, independent rows and rational non-zero minor determinants are written to:
`results/treated_identifiability_rank_results.txt`.

The result is conditional on fixing `n = 2`; it does not establish identifiability of a continuously unknown Hill exponent.

### 2. Matched-killing comparison (manuscript Section 6.4 / Figure 5)
`scripts/new_revision_numerics.py`

Reproduces the matched initial drug-loss calculation for the surface-scaled model and the volume-proportional benchmark under constant concentration `Cc = 10 mg/L`.

Outputs:

- `results/matched_killing_summary.csv`
- `figures/fig5_matched_killing.png`
- `figures/fig5_matched_killing.pdf`

Key reproduced values include:

- `gamma = 0.0248588618` for `V0 = 100 mm^3`;
- surface-model zero event at about `30.97006 d`;
- Theorem 3.4 upper bound about `34.94634 d`;
- linear-model residual about `20.0449 mm^3` at day 110;
- `gamma = 9.15808299` for `V0 = 2e-6 mm^3`;
- linear cutoff crossing about `0.0365161 d`;
- surface-model zero event about `0.1067528 d`;
- linear-model volume about `6.65808e-7 mm^3` at day 0.5.

### 3. `Emax = 1` mechanism comparison (manuscript Section 6.4 / Figure 6)
Reproduces the three-day continued regimen comparison between purely inhibitory `Emax = 1` and the illustrative surface-scaled-loss case `Emax = 1.5`.

Outputs:

- `results/emax_comparison_summary.csv`
- `figures/fig6_emax.png`
- `figures/fig6_emax.pdf`

Key values:

- `Emax = 1`: `Qbar = 0.25861097`, no zero event, `V(730) = 63.9440 mm^3`;
- `Emax = 1.5`: zero event at `79.1430715 d`.

### 4. Symmetry and synthetic-noise illustration (manuscript Section 6.5 / Figure 7)
Reproduces the two symmetry-related untreated parameter sets and the synthetic log-noise demonstration.

Outputs:

- `results/symmetry_observations.csv`
- `results/symmetry_lambda_scan.csv`
- `figures/fig7_symmetry.png`
- `figures/fig7_symmetry.pdf`

The script uses 13 observations at days `0,5,...,60`, Gaussian log-noise with standard deviation `0.05`, and random seed `20261015`.

It reproduces:

- maximum numerical tumour-volume difference between the symmetry-related sets of approximately `6e-12 mm^3`;
- a flat volume-only likelihood slice along the pure scaling family;
- the joint-output conditional slice minimum near `lambda = 0.98` for the stated noise realisation.

### 5. Near-boundary analytical checks
`results/near_boundary_checks.csv`

Recomputes the periodic average multiplier for the two shallow-boundary schedules discussed in the manuscript:

- `(D, tau) = (26, 5.5)`: `Qbar ≈ 0.00616064`;
- `(D, tau) = (28, 5.625)`: `Qbar ≈ 0.000429489`.

The file also reports the corresponding necessary dose thresholds from Corollary 3.7, showing explicitly that these schedules lie far above the weak necessary peak threshold.

## Reproduction

Create a Python environment with the packages in `requirements.txt`, then run from the package root:

```bash
python scripts/run_all.py
```

This regenerates all numerical CSV/text outputs and Figures 5–7 contained in this update package.

## Directory structure

- `scripts/` — executable verification/reproduction scripts
- `results/` — machine-readable numerical outputs and exact-rank certificates
- `figures/` — new figures introduced by the latest manuscript revision
- `manuscript_context/` — a snapshot of the manuscript source corresponding to these additions
- `requirements.txt` — Python dependencies
- `CHANGELOG.md` — summary of additions relative to the earlier archive
- `ZENODO_UPDATE_NOTES.txt` — suggested release/update notes for the new Zenodo version

## Scope

The numerical values are illustrative and uncalibrated. These scripts reproduce the mathematical and computational examples reported in the manuscript; they do not establish clinically effective treatment schedules.
